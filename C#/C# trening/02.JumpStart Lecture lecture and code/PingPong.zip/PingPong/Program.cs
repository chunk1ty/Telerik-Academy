﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace PingPong
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;

            Console.CursorVisible = false;

            Random random = new Random();            

            int screenWidth = Console.WindowWidth;
            int screenHeight = Console.WindowHeight;

            const int playerHeight = 4;

            int topWallY = 2;
            int bottomWallY = screenHeight - 1;
            int fieldHeight = bottomWallY - topWallY - 1;

            // draw field borders
            for (int i = 0; i < screenWidth - 1; i++)
            {
                Console.SetCursorPosition(i, 0);
                Console.Write("=");
                Console.SetCursorPosition(i, topWallY);
                Console.Write("=");
                Console.SetCursorPosition(i, bottomWallY);
                Console.Write("=");
            }

            int player1Score = 0;
            int player2Score = 0;

            int player1PosX = 3;
            int player2PosX = screenWidth - 4;
            int player1PosY = topWallY + 1 + (fieldHeight - playerHeight) / 2;
            int player2PosY = player1PosY;

            int ballPosX = screenWidth / 2;
            int ballPosY = topWallY + 1 + random.Next(fieldHeight);
            int ballMoveDirection = random.Next(4); // 0 - NE 1 - SE 2 - SW 3 - NW

            // draw players
            for (int i = 0; i < playerHeight; i++)
            {
                Console.SetCursorPosition(player1PosX, player1PosY + i);
                Console.Write("\u2016");
                Console.SetCursorPosition(player2PosX, player2PosY + i);
                Console.Write("\u2016");
            }

            while (true)
            {
                int playerWin = 0;

                if (ballPosX == 0) {
                    playerWin = 2;
                    player2Score++;
                }
                else if (ballPosX == screenWidth - 1) {
                    playerWin = 1;
                    player1Score++;
                }

                if (playerWin != 0)
                {
                    // clear ball
                    Console.SetCursorPosition(ballPosX, ballPosY);
                    Console.Write(" ");

                    // reset ball position and direction
                    ballPosX = screenWidth / 2;
                    ballPosY = topWallY + 1 + random.Next(fieldHeight);
                    ballMoveDirection = random.Next(4);

                    // draw ball
                    Console.SetCursorPosition(ballPosX, ballPosY);
                    Console.Write("@");

                    Thread.Sleep(1000);
                }

                // get players input
                int oldPlayer1PosY = player1PosY;
                int oldPlayer2PosY = player2PosY;

                // update players positions
                if (Console.KeyAvailable)
                {
                    var keyInfo = Console.ReadKey(true);
                    switch (keyInfo.Key)
                    {
                        case ConsoleKey.Q:
                            if (player1PosY > topWallY + 1)
                                player1PosY--;
                            break;
                        case ConsoleKey.A:
                            if (player1PosY + playerHeight < bottomWallY)
                                player1PosY++;
                            break;
                        case ConsoleKey.P:
                            if (player2PosY > topWallY + 1)
                                player2PosY--;
                            break;
                        case ConsoleKey.L:
                            if (player2PosY + playerHeight < bottomWallY)
                                player2PosY++;
                            break;
                    }
                }

                bool isPlayerHit = false;
                bool isWallHit = false;

                int playerTop, playerBottom;

                // change ball direction if wall or player is hit
                switch(ballMoveDirection)
                {
                    case 0: // NE
                        isWallHit = (ballPosY == topWallY + 1);
                        playerTop = isWallHit ? player2PosY-1 : player2PosY;
                        playerBottom = player2PosY + playerHeight + 1;
                        isPlayerHit = ballPosX + 1 == player2PosX && ballPosY >= playerTop && ballPosY < playerBottom;
                        if (isWallHit && isPlayerHit) ballMoveDirection = 2;
                        else if (isWallHit) ballMoveDirection = 1;
                        else if (isPlayerHit) ballMoveDirection = 3;
                        break;
                    case 1: // SE
                        isWallHit = (ballPosY == bottomWallY - 1);
                        playerTop = player2PosY - 1;
                        playerBottom = isWallHit ? player2PosY + playerHeight + 1 : player2PosY + playerHeight;
                        isPlayerHit = ballPosX + 1 == player2PosX && ballPosY >= playerTop && ballPosY < playerBottom;
                        if (isWallHit && isPlayerHit) ballMoveDirection = 3;
                        else if (isWallHit) ballMoveDirection = 0;
                        else if (isPlayerHit) ballMoveDirection = 2;
                        break;
                    case 2: // SW
                        isWallHit = (ballPosY == bottomWallY - 1);
                        playerTop = player1PosY - 1;
                        playerBottom = isWallHit ? player1PosY + playerHeight + 1 : player1PosY + playerHeight;
                        isPlayerHit = ballPosX - 1 == player1PosX && ballPosY >= playerTop && ballPosY < playerBottom;
                        if (isWallHit && isPlayerHit) ballMoveDirection = 0;
                        else if (isWallHit) ballMoveDirection = 3;
                        else if (isPlayerHit) ballMoveDirection = 1;
                        break;
                    case 3: // NW
                        isWallHit = (ballPosY == topWallY + 1);
                        playerTop = isWallHit ? player1PosY - 1 : player1PosY;
                        playerBottom = player1PosY + playerHeight + 1;
                        isPlayerHit = ballPosX - 1 == player1PosX && ballPosY >= playerTop && ballPosY < playerBottom;
                        if (isWallHit && isPlayerHit) ballMoveDirection = 1;
                        else if (isWallHit) ballMoveDirection = 2;
                        else if (isPlayerHit) ballMoveDirection = 0;
                        break;
                }

                // update ball position
                int oldBallPosX = ballPosX;
                int oldBallPosY = ballPosY;
                switch(ballMoveDirection)
                {
                    case 0: // NE
                        ballPosX++; ballPosY--;
                        break;
                    case 1: // SE
                        ballPosX++; ballPosY++;
                        break;
                    case 2: // SW
                        ballPosX--; ballPosY++;
                        break;
                    case 3: // NW
                        ballPosX--; ballPosY--;
                        break;
                }

                // clear ball
                Console.SetCursorPosition(oldBallPosX, oldBallPosY);
                Console.Write(" ");

                // if player1's position has changed
                if (oldPlayer1PosY != player1PosY)
                {
                    // clear player1 at his old position
                    for (int i = 0; i < playerHeight; i++)
                    {
                        Console.SetCursorPosition(player1PosX, oldPlayer1PosY + i);
                        Console.Write(" ");
                    }

                    // draw player1 at his new position
                    for (int i = 0; i < playerHeight; i++)
                    {
                        Console.SetCursorPosition(player1PosX, player1PosY + i);
                        Console.Write("\u2016");
                    }
                }

                // if player2's position has changed
                if (oldPlayer2PosY != player2PosY)
                {
                    // clear player2 at his old position
                    for (int i = 0; i < playerHeight; i++)
                    {
                        Console.SetCursorPosition(player2PosX, oldPlayer2PosY + i);
                        Console.Write(" ");
                    }

                    // draw player2 at his new position
                    for (int i = 0; i < playerHeight; i++)
                    {
                        Console.SetCursorPosition(player2PosX, player2PosY + i);
                        Console.Write("\u2016");
                    }
                }

                // draw ball
                Console.SetCursorPosition(ballPosX, ballPosY);
                Console.Write("@");

                // draw scores
                string scores = String.Format("{0} : {1}", player1Score, player2Score);
                int scoresPosX = (screenWidth - scores.Length) / 2;
                Console.SetCursorPosition(scoresPosX, 1);
                Console.Write(scores);

                Thread.Sleep(60);
            }
            // \u2016
            // ==============================================
            //                     0 : 1
            // ==============================================
            //                                          
            //   |                                        
            //   |                                        
            //   |                                       |
            //   |                  @                    | 
            //                                           |
            //                                           |
            //                                          
            //
            //
            // ==============================================
        }
    }
}
